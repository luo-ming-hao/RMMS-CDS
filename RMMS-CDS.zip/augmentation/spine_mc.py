"""Illustrative Spine-MC: sampled augmentations + anatomy-aware rejection.

Input: grayscale float image in [0,1], binary mask [H,W]. The mask uses only
synchronized geometry; photometric/noise/occlusion affect the image alone.
"""
from __future__ import annotations

import math
import cv2
import numpy as np


class SpineMCAugmentation:
    def __init__(self, seed: int | None = None, max_resamples: int = 10):
        self.rng = np.random.default_rng(seed)
        self.max_resamples = max_resamples

    @staticmethod
    def _stats(mask: np.ndarray) -> tuple[int, int, int, int]:
        binary = (mask > 0).astype(np.uint8)
        area = int(binary.sum())
        rows = int(np.count_nonzero(binary.any(axis=1)))
        if area == 0:
            return 0, 0, 0, 0
        count, _, stats, _ = cv2.connectedComponentsWithStats(binary, 8)
        components = count - 1
        largest = int(stats[1:, cv2.CC_STAT_AREA].max())
        return area, rows, components, largest

    def _plausible(self, original: np.ndarray, augmented: np.ndarray) -> bool:
        old_area, old_rows, old_cc, old_largest = self._stats(original)
        area, rows, cc, largest = self._stats(augmented)
        if old_area == 0:
            return area == 0
        area_ratio = area / old_area
        row_ratio = rows / max(old_rows, 1)
        cc_limit = max(old_cc + 2, math.ceil(old_cc * 1.5))
        return (
            0.85 <= area_ratio <= 1.15
            and row_ratio >= 0.85
            and cc <= cc_limit
            and largest >= 0.75 * old_largest
        )

    def _affine(self, image: np.ndarray, mask: np.ndarray):
        h, w = image.shape
        angle = np.deg2rad(self.rng.uniform(-4, 4))
        shear = np.deg2rad(self.rng.uniform(-3, 3))
        sx, sy = self.rng.uniform(0.97, 1.03), self.rng.uniform(0.95, 1.05)
        rot = np.array([[np.cos(angle), -np.sin(angle)],
                        [np.sin(angle),  np.cos(angle)]], dtype=np.float32)
        shr = np.array([[1, np.tan(shear)], [0, 1]], dtype=np.float32)
        scale = np.diag([sx, sy]).astype(np.float32)
        mat2 = rot @ shr @ scale
        center = np.array([w / 2, h / 2], dtype=np.float32)
        delta = np.array([self.rng.uniform(-0.015, 0.015) * w,
                          self.rng.uniform(-0.015, 0.015) * h], dtype=np.float32)
        affine = np.column_stack((mat2, center + delta - mat2 @ center))
        warped_image = cv2.warpAffine(image, affine, (w, h),
                                      flags=cv2.INTER_LINEAR,
                                      borderMode=cv2.BORDER_REFLECT_101)
        warped_mask = cv2.warpAffine(mask, affine, (w, h),
                                     flags=cv2.INTER_NEAREST,
                                     borderMode=cv2.BORDER_CONSTANT,
                                     borderValue=0)
        return warped_image, (warped_mask > 0).astype(np.uint8)

    def _appearance(self, image: np.ndarray) -> np.ndarray:
        gamma = float(self.rng.uniform(0.85, 1.15))
        alpha = float(self.rng.uniform(0.9, 1.1))
        beta = float(self.rng.uniform(-0.05, 0.05))
        image = np.clip(alpha * np.power(np.clip(image, 0, 1), gamma) + beta,
                        0, 1)
        if self.rng.random() < 0.55:
            sigma = float(self.rng.uniform(0.004, 0.02))
            image += self.rng.normal(0, sigma, size=image.shape).astype(np.float32)
        if self.rng.random() < 0.30:
            image = cv2.GaussianBlur(image, (3, 3),
                                     sigmaX=float(self.rng.uniform(0.2, 0.8)))
        return np.clip(image, 0, 1).astype(np.float32)

    def _safe_occlusion(self, image: np.ndarray, mask: np.ndarray) -> np.ndarray:
        if self.rng.random() >= 0.30:
            return image
        h, w = image.shape
        for _ in range(12):
            rw = max(2, int(w * self.rng.uniform(0.035, 0.12)))
            rh = max(2, int(h * self.rng.uniform(0.02, 0.08)))
            x0 = int(self.rng.integers(0, max(1, w - rw + 1)))
            y0 = int(self.rng.integers(0, max(1, h - rh + 1)))
            # Prefer off-spine or near-edge occlusion: <= 1% of total mask area.
            covered = int(mask[y0:y0 + rh, x0:x0 + rw].sum())
            if covered > 0.01 * max(1, mask.sum()):
                continue
            out = image.copy()
            local_mean = float(np.mean(image[max(0, y0 - 4):min(h, y0 + rh + 4),
                                             max(0, x0 - 4):min(w, x0 + rw + 4)]))
            out[y0:y0 + rh, x0:x0 + rw] = local_mean
            return out
        return image

    def __call__(self, image: np.ndarray, mask: np.ndarray):
        image = np.asarray(image, dtype=np.float32)
        mask = (np.asarray(mask) > 0).astype(np.uint8)
        if image.shape != mask.shape or image.ndim != 2:
            raise ValueError("Image and mask must be matching 2-D arrays")
        if np.min(image) < 0 or np.max(image) > 1:
            raise ValueError("Image must be normalized to [0,1] first")
        for _ in range(self.max_resamples):
            aug_image, aug_mask = self._affine(image, mask)
            if not self._plausible(mask, aug_mask):
                continue
            aug_image = self._appearance(aug_image)
            aug_image = self._safe_occlusion(aug_image, aug_mask)
            return aug_image, aug_mask
        # Preserve a valid original sample if all generated candidates are rejected.
        return image.copy(), mask.copy()
