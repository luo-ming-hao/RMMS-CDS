import numpy as np
import torch
from models.msrnet import MSRNet
from preprocessing.spine_roi_prep import SpineROIPrep
from augmentation.spine_mc import SpineMCAugmentation


def test_shapes_and_binary_masks():
    im = np.zeros((128, 96), np.uint16)
    im[8:120, 36:58] = 2000
    seg = (im > 0).astype(np.uint8)
    result = SpineROIPrep(output_size=(64, 64))(im, seg)
    assert result.image.shape == (64, 64)
    assert result.mask.shape == (64, 64)
    ia, ma = SpineMCAugmentation(seed=11)(result.image, result.mask)
    assert ia.shape == ma.shape == (64, 64)
    assert set(np.unique(ma)).issubset({0, 1})
    with torch.no_grad():
        out = MSRNet(base_channels=8).eval()(torch.from_numpy(ia)[None, None])
    assert out.shape == (1, 1, 64, 64)
