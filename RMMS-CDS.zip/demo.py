"""Smoke-test all three modules without a patient dataset.

Run: python demo.py
This does not train the model or reproduce published metrics.
"""
import cv2
import numpy as np
import torch

from models.msrnet import MSRNet
from preprocessing.spine_roi_prep import SpineROIPrep
from augmentation.spine_mc import SpineMCAugmentation


def synthetic_example(height=256, width=160):
    """A toy bright curved object; NOT an anatomical spine X-ray."""
    yy, xx = np.mgrid[:height, :width]
    center = width / 2 + 12 * np.sin(yy / 34.0)
    spine = (np.abs(xx - center) < 11) & (yy > 18) & (yy < height - 18)
    rng = np.random.default_rng(11)
    image = np.clip(0.22 + 0.58 * spine + rng.normal(0, 0.03, (height, width)), 0, 1)
    return (image * 65535).astype(np.uint16), spine.astype(np.uint8)


def main():
    image, mask = synthetic_example()
    prep = SpineROIPrep(output_size=(128, 96))
    result = prep(image, mask)
    assert result.mask is not None
    augment = SpineMCAugmentation(seed=11)
    aug_image, aug_mask = augment(result.image, result.mask)
    assert aug_image.shape == aug_mask.shape == (128, 96)
    assert set(np.unique(aug_mask)).issubset({0, 1})
    model = MSRNet(in_channels=1, base_channels=8).eval()
    x = torch.from_numpy(aug_image).unsqueeze(0).unsqueeze(0)
    with torch.no_grad():
        logits = model(x)
        prediction = (torch.sigmoid(logits) > 0.5).to(torch.uint8)
    assert logits.shape == (1, 1, 128, 96)
    print("PASS: image:", aug_image.shape,
          "mask:", aug_mask.shape,
          "model logits:", tuple(logits.shape),
          "prediction:", tuple(prediction.shape))
    print("Note: logits are from an UNTRAINED randomly initialized network.")


if __name__ == "__main__":
    main()
