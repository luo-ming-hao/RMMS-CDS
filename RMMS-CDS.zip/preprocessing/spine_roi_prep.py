"""Illustrative Spine-ROI Prep (quantile normalization + image-only ROI).

IMPORTANT: The ROI detector here is an image-processing heuristic, not a
validated vertebral locator. It can fail on real X-rays. It NEVER uses a
segmentation ground-truth mask to select ROI (avoids label leakage).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import cv2
import numpy as np


@dataclass
class ROIResult:
    image: np.ndarray                 # float32 [H, W], in [0, 1]
    mask: Optional[np.ndarray]        # uint8 [H, W], values 0 or 1
    bbox: tuple[int, int, int, int]  # crop in original image: (x0,y0,x1,y1)
    original_shape: tuple[int, int]


class SpineROIPrep:
    def __init__(
        self,
        output_size: tuple[int, int] = (256, 128),  # (height, width)
        low_quantile: float = 1.0,
        high_quantile: float = 99.0,
        roi_margin: float = 0.15,
        min_crop_width: float = 0.55,
    ):
        if not (0 <= low_quantile < high_quantile <= 100):
            raise ValueError("Quantiles must satisfy 0 <= low < high <= 100")
        self.output_size = output_size
        self.low_quantile = low_quantile
        self.high_quantile = high_quantile
        self.roi_margin = roi_margin
        self.min_crop_width = min_crop_width

    def normalize(self, image: np.ndarray) -> np.ndarray:
        image = np.asarray(image, dtype=np.float32)
        if image.ndim != 2:
            raise ValueError("Expected grayscale X-ray, shape [H,W]")
        lo, hi = np.percentile(image, [self.low_quantile, self.high_quantile])
        if hi <= lo + 1e-7:
            return np.zeros_like(image, dtype=np.float32)
        return np.clip((image - lo) / (hi - lo), 0.0, 1.0).astype(np.float32)

    def estimate_roi(self, normalized: np.ndarray) -> tuple[int, int, int, int]:
        """Rough bright-structure + elongated-component screening; not learned."""
        h, w = normalized.shape
        gray = (255 * normalized).astype(np.uint8)
        smooth = cv2.GaussianBlur(gray, (5, 5), 0)
        _, binary = cv2.threshold(smooth, 0, 255,
                                  cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        # Connect nearby high-intensity bone structures vertically.
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 9))
        binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel)
        count, labels, stats, centers = cv2.connectedComponentsWithStats(binary)

        candidates = []
        for idx in range(1, count):
            x, y, bw, bh, area = (int(v) for v in stats[idx])
            if area < 0.001 * h * w or bh < 0.12 * h:
                continue
            if bw > 0.85 * w:
                continue
            center_offset = abs(float(centers[idx, 0]) / w - 0.5)
            score = 2.5 * bh / h - 0.6 * bw / w - 1.2 * center_offset
            candidates.append((score, x, y, bw, bh))

        if candidates:
            _, x, y, bw, bh = max(candidates, key=lambda item: item[0])
            crop_width = max(int(bw * (1 + 2 * self.roi_margin)),
                             int(self.min_crop_width * w))
            crop_height = max(int(bh * (1 + 2 * self.roi_margin)),
                              int(0.80 * h))
            center_x = x + bw / 2
            center_y = y + bh / 2
        else:
            # Safe *illustrative* fallback; may not contain off-center scoliosis.
            crop_width = int(0.75 * w)
            crop_height = h
            center_x, center_y = w / 2, h / 2

        crop_width = min(crop_width, w)
        crop_height = min(crop_height, h)
        x0 = max(0, min(w - crop_width, int(round(center_x - crop_width / 2))))
        y0 = max(0, min(h - crop_height, int(round(center_y - crop_height / 2))))
        return x0, y0, x0 + crop_width, y0 + crop_height

    def __call__(
        self,
        image: np.ndarray,
        mask: Optional[np.ndarray] = None,
        roi_box: Optional[tuple[int, int, int, int]] = None,
    ) -> ROIResult:
        image = np.asarray(image)
        original_shape = image.shape
        normalized = self.normalize(image)
        h, w = original_shape
        box = self.estimate_roi(normalized) if roi_box is None else roi_box
        x0, y0, x1, y1 = (int(v) for v in box)
        if not (0 <= x0 < x1 <= w and 0 <= y0 < y1 <= h):
            raise ValueError("Invalid ROI box for input image")

        out_h, out_w = self.output_size
        crop = normalized[y0:y1, x0:x1]
        processed = cv2.resize(crop, (out_w, out_h), interpolation=cv2.INTER_LINEAR)
        processed_mask = None
        if mask is not None:
            mask = np.asarray(mask)
            if mask.shape != original_shape:
                raise ValueError("Image and mask must have the same H,W")
            crop_mask = (mask[y0:y1, x0:x1] > 0).astype(np.uint8)
            processed_mask = cv2.resize(crop_mask, (out_w, out_h),
                                        interpolation=cv2.INTER_NEAREST)
        return ROIResult(
            processed.astype(np.float32), processed_mask,
            (x0, y0, x1, y1), original_shape,
        )
