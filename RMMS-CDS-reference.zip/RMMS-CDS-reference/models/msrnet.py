"""Illustrative MSRNet-style segmentation network, NOT the original trained model.

The manuscript describes a U-Net-like residual encoder/decoder, a CEM with
3x3 and 5x3 depthwise-separable branches, an APC dilated-pooling pyramid,
and multi-scale fusion. Precise channel widths/topology are unspecified;
the choices below are explicitly illustrative.
"""
from __future__ import annotations

import torch
from torch import nn
import torch.nn.functional as F


def conv_bn_act(in_ch: int, out_ch: int, kernel_size=3, dilation=1) -> nn.Sequential:
    if isinstance(kernel_size, int):
        padding = dilation * (kernel_size // 2)
    else:
        padding = tuple(dilation * (k // 2) for k in kernel_size)
    return nn.Sequential(
        nn.Conv2d(in_ch, out_ch, kernel_size, padding=padding,
                  dilation=dilation, bias=False),
        nn.BatchNorm2d(out_ch),
        nn.ReLU(inplace=True),
    )


class ResidualBlock(nn.Module):
    def __init__(self, in_ch: int, out_ch: int):
        super().__init__()
        self.block = nn.Sequential(
            conv_bn_act(in_ch, out_ch, 3),
            nn.Conv2d(out_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
        )
        self.skip = nn.Identity() if in_ch == out_ch else nn.Conv2d(in_ch, out_ch, 1)
        self.act = nn.ReLU(inplace=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.act(self.block(x) + self.skip(x))


class ContextEnhancementModule(nn.Module):
    """Local 3x3 and asymmetric depthwise-separable 5x3 context branches."""
    def __init__(self, channels: int):
        super().__init__()
        self.local = conv_bn_act(channels, channels, 3)
        self.depthwise = nn.Sequential(
            nn.Conv2d(channels, channels, (5, 3), padding=(2, 1),
                      groups=channels, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, 1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
        )
        self.fuse = nn.Conv2d(2 * channels, channels, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return F.relu(x + self.fuse(torch.cat(
            (self.local(x), self.depthwise(x)), dim=1)))


class APCPyramid(nn.Module):
    """Illustrative atrous-convolution + pooled-context pyramid."""
    def __init__(self, channels: int, dilations=(1, 2, 4)):
        super().__init__()
        inner = max(8, channels // 4)
        self.atrous = nn.ModuleList([
            conv_bn_act(channels, inner, 3, dilation=d)
            for d in dilations
        ])
        self.pool_proj = nn.Conv2d(channels, inner, 1, bias=False)
        self.fuse = conv_bn_act(inner * (len(dilations) + 1), channels, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        pooled = F.adaptive_avg_pool2d(x, 1)
        pooled = self.pool_proj(pooled)
        pooled = F.interpolate(pooled, size=x.shape[-2:], mode="bilinear",
                               align_corners=False)
        return self.fuse(torch.cat([*(branch(x) for branch in self.atrous),
                                    pooled], dim=1))


class DecoderBlock(nn.Module):
    def __init__(self, in_ch: int, skip_ch: int, out_ch: int):
        super().__init__()
        # Kernel 3 deconvolution, consistent with the high-level paper description.
        self.up = nn.ConvTranspose2d(in_ch, out_ch, 3, stride=2,
                                     padding=1, output_padding=1)
        self.refine = ResidualBlock(out_ch + skip_ch, out_ch)

    def forward(self, x: torch.Tensor, skip: torch.Tensor) -> torch.Tensor:
        x = self.up(x)
        if x.shape[-2:] != skip.shape[-2:]:
            x = F.interpolate(x, size=skip.shape[-2:], mode="bilinear",
                              align_corners=False)
        return self.refine(torch.cat((x, skip), dim=1))


class MSRNet(nn.Module):
    """Single-channel X-ray in -> single-channel segmentation *logits* out.

    Input:  [batch, in_channels, height, width]
    Output: [batch, 1, height, width] (apply sigmoid for probabilities)
    """
    def __init__(self, in_channels: int = 1, base_channels: int = 16):
        super().__init__()
        c = base_channels
        self.stem = ResidualBlock(in_channels, c)
        self.enc1 = ResidualBlock(c, c * 2)
        self.enc2 = ResidualBlock(c * 2, c * 4)
        self.bottleneck = ResidualBlock(c * 4, c * 8)
        self.pool = nn.MaxPool2d(2)
        self.cem1 = ContextEnhancementModule(c * 2)
        self.cem2 = ContextEnhancementModule(c * 4)
        self.apc = APCPyramid(c * 8)
        self.dec2 = DecoderBlock(c * 8, c * 4, c * 4)
        self.dec1 = DecoderBlock(c * 4, c * 2, c * 2)
        self.dec0 = DecoderBlock(c * 2, c, c)
        self.multi_scale_fusion = conv_bn_act(c + c * 2 + c * 4, c, 1)
        self.head = nn.Conv2d(c, 1, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        e0 = self.stem(x)
        e1 = self.cem1(self.enc1(self.pool(e0)))
        e2 = self.cem2(self.enc2(self.pool(e1)))
        center = self.apc(self.bottleneck(self.pool(e2)))
        d2 = self.dec2(center, e2)
        d1 = self.dec1(d2, e1)
        d0 = self.dec0(d1, e0)
        size = d0.shape[-2:]
        fused = self.multi_scale_fusion(torch.cat([
            d0,
            F.interpolate(d1, size=size, mode="bilinear", align_corners=False),
            F.interpolate(d2, size=size, mode="bilinear", align_corners=False),
        ], dim=1))
        return self.head(fused)


if __name__ == "__main__":
    model = MSRNet()
    with torch.no_grad():
        y = model(torch.rand(1, 1, 128, 256))
    print("Output shape:", tuple(y.shape))
    print("Parameters:", sum(p.numel() for p in model.parameters()))
