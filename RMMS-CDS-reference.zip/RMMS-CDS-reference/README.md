# RMMS-CDS — Illustrative Reference Implementation

**Status: illustrative scaffold, not the original experiment code.**

This repository folder contains a **simplified reimplementation** of the three components
conceptually described in the manuscript *RMMS-CDS: A Decision-Support Diagnostic
System for Scoliosis Assessment from Spinal X-rays*:

- `models/msrnet.py`: U-Net-like residual encoder/decoder, 3x3 + depthwise-separable
  5x3 context enhancement (CEM), an atrous/pooling pyramid (APC), and multi-scale fusion.
- `preprocessing/spine_roi_prep.py`: quantile clipping, intensity normalization,
  image-based coarse ROI estimation, synchronized image/mask cropping and resizing.
- `augmentation/spine_mc.py`: Monte Carlo sampling of mild affine, photometric,
  noise, blur, and off-spine occlusion transformations with basic structural rejection.
- `demo.py`: checks that the components run together using a **synthetic** toy image.

## Quick start

```bash
pip install -r requirements.txt
python demo.py
```

The model returns logits. Use `torch.sigmoid(logits)` for probabilities and train with
an appropriate segmentation loss, for example Dice + BCE. This package is a module
demonstration: it **does not include training loops, fitted weights, clinical measurement
algorithms, or the original radiographic dataset**.

## Key limitations and provenance

- The paper does not fully specify all channel widths, layer counts, dilation rates,
  ROI selection settings, augmentation probabilities, or rejection thresholds. Values
  here are **illustrative defaults**, not verified experimental settings.
- The original paper discusses mild thin-plate-spline perturbations; this simplified
  code uses *affine* warps only and **does not implement TPS**.
- Coarse ROI detection is a heuristic, **not a validated anatomical localizer**. It
  can exclude off-center spines. Check the retained anatomy before use.
- Never use ground-truth test masks for locating ROI; this implementation estimates
  it from the image alone (unless the caller explicitly supplies an ROI box).
- For valid evaluation, split patients / originals into train, validation, and test
  **before** augmentation; augment **only training data**.
- The synthetic demo and randomly initialized weights do not reproduce any paper
  performance figures, including IoU, DSC, or Cobb angle measurement errors.

For an archival reproducibility release, replace all approximated parts with the
**actual experiment implementation** and include complete settings, preprocessing,
training scripts, dependency locks, model checkpoints (when permitted), and testing
instructions. Label any remaining non-released modules clearly.
